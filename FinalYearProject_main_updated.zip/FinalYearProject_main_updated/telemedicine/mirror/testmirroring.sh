while sleep 0.1;
  do
     curl -X GET http://telemedicinebff.telemedicinebff:5000/combined_data/1/708a2528-b512164c-0f547574-dfbad394-88a66bdc
    echo "";
  done ;
